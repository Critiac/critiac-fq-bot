const { MessageActionRow, MessageButton, MessageSelectMenu, MessageEmbed } = require("discord.js")
const { version: discordjsVersion } = require("discord.js")
const config = require("../../botconfig/main")
module.exports = {
  name: "help",
  run: async (client, message, args) => {
    const row = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setCustomId('select')
          .setPlaceholder('CRITIAC FQ|COMMANDS MENU')

          .addOptions([
            {
              label: 'Main Menu',
              description: 'Shows the main menu',
              emoji: "<:Home:1342121951681843202>",
              value: '0',
            },
            {
              label: 'Config Commands',
              description: 'Shows all the config commands',
              emoji: "<:icon_red_mod:1342131343777337560>",
              value: '1',
            },

            {
              label: 'Fun Commands',
              description: 'Shows all the fun commands',
              emoji: "<:partnership:1342123430589370418>",
              value: '3',
            },
            {
              label: 'Games Commands',
              description: 'Shows all the game commands',
              emoji: "<:x_games:1342123766427156572>",
              value: '4',
            },

            {
              label: 'Information Commands',
              description: 'Shows all the information commands',
              emoji: "<:red_owner1:1342133207386165290>",
              value: '5',
            },
            {
              label: 'Moderation Commands',
              description: 'Shows all the moderation commands',
              emoji: "<:staff_red:1342125054514958419>",
              value: '6',
            },
            {
              label: 'Coding Commands',
              description: 'Shows all the coding commands',
              emoji: "<:Replit:1342125418685399151>",
              value: '8',
            },
            {
              label: 'Uptimer Commands',
              description: 'Shows all the uptimer commands',
              emoji: "<:Time:1342133125802758228>",
              value: '9',
            },
            {
              label: 'Utility Commands',
              description: 'Shows all the utility commands',
              emoji: "<:config:1342122147170091190>",
              value: '7',
            },
            {
              label: 'Image Commands',
              description: 'Shows all the image commands',
              emoji: "<:mail:1342131552058085388>",
              value: '10',
            },
            {
              label: 'Economy Commands',
              description: 'Shows all the economy commands',
              emoji: "<:economy:1342131323988475915>",
              value: '11',
            },
          ]),
      );
    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setLabel("Youtube")

          .setStyle("LINK")
          .setEmoji("<:exe_youtube:1304700222999363645>")
          .setURL("https://www.youtube.com/@xtremefq"),
        new MessageButton()
          .setLabel("Support Server")

          .setStyle("LINK")
          .setEmoji("<:exe_ticket:1304700220675850240>")
          .setURL("https://discord.gg/nXu9rqv6Tg"),
        new MessageButton()
          .setLabel("Vote me")

          .setStyle("LINK")
          .setEmoji("<:exe_like:1304700217677053952>")
          .setURL("https://discord.gg/nXu9rqv6Tg")
      )

    const embed = new MessageEmbed()
      .setTitle("**CRITIAC HELP PANNEL**")
      .setDescription(`<:bot_orange:1342150028231446559> __**BOT INFO**__
> <a:orange_dot:1342114334511333426> Prefix: \` ${config.prefix}\`

<a:lightning:1342151691088433193> __**BOT'S COMMANDS**__
>  <a:orange_dot:1342114334511333426> Config Commands
>  <a:orange_dot:1342114334511333426> Fun Commands
>  <a:orange_dot:1342114334511333426> Games Commands
>  <a:orange_dot:1342114334511333426> Information Commands
>  <a:orange_dot:1342114334511333426> Moderation Commands
>  <a:orange_dot:1342114334511333426> Coding Commands
>  <a:orange_dot:1342114334511333426> Uptimer Commands
>  <a:orange_dot:1342114334511333426> Utility Commands
>  <a:orange_dot:1342114334511333426> Image Commands
>  <a:orange_dot:1342114334511333426> Economy Commands

<:ppl:1342150383979597907> __**BOT'S STATUS**__
> <a:orange_dot:1342114334511333426> Current Ping  ${client.ws.ping}ms
> <a:orange_dot:1342114334511333426> Discord.js Version: ${discordjsVersion}
> <a:orange_dot:1342114334511333426> Running on Node ${process.version} on ${process.platform} ${process.arch}`)
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setColor("#ff5a00")


    let sendmsg = message.channel.send({ embeds: [embed], components: [row, row2] })

    let embed1 = new MessageEmbed()
      .setColor('#ff5a00')
      .setTitle('**CRITIAC HELP PANNEL**')
      .addFields(
        { name: "**CONFIG COMMANDS**", value: "`set-countingchannel`, `setwelcomechannel`, `setleavechannel`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 1')




    let embed3 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields(
        { name: "**FUN COMMANDS**", value: "`8ball`, `activity`, `pixelize`, `meme`" })
      .setColor("#ff5a00")
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setFooter('Page 3')

    let embed4 = new MessageEmbed()

      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields(
        { name: "**GAMES COMMANDS**", value: "`c4`, `tictactoe`, `roadrace`, `snake`, `quickclick`, `catchthefish`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 4')

    let embed5 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields(
        { name: "**INFO COMMANDS**", value: "`help`, `cmdhelp`, `botinfo`, `ping`, `invite`, `embed`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 5')

    let embed6 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields(
        { name: "**MOD COMMANDS**", value: "`ban`, `addroleall`, `removeroleall`, `softban`, `purge`, `mute`, `kick`, `tempmute`, `nuke` `stealemoji`" })
      .setFooter('Page 6')
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
    let embed8 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields(
        { name: "**Coding Commands**", value: "`Src`" })
      .setFooter('Page 8')
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
    let embed7 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields({ name: "**UTILITY COMMANDS**", value: "`addtag`, `edittag`, `removetag`, `afk`, `rolelist`, `snipe`, `timer`, `calculator`, `avatar`, `serverinfo`, `ss`, `dump`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 7')
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")

    let embed9 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields({ name: "**UPTIMER COMMANDS**", value: "`add-monitor`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 9')

    let embed11 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields({ name: "**ECONOMY COMMANDS**", value: "`balance`, `deposit`, `withdraw`, `search`, `shop`, `inv`, `pet`, `adopt`, `buy`, `sell`, `use`, `gamble`, `multi`, `beg`, `daily`, `fish`, `hunt`, `rob`, `rich` `postmeme`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 11')

    let embed10 = new MessageEmbed()
      .setTitle('**CRITIAC HELP PANNEL**')
      .setColor('#ff5a00')
      .addFields({ name: "**UTILITY COMMANDS**", value: "`anime`, `art`, `banner`, `cat`, `color`, `dog`, `gif`, `ss`" })
      .setImage("https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&")
      .setColor("#ff5a00")
      .setFooter('Page 10')
    const filter = i => i.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({
      filter,
      time: 40000000,
      componentType: "SELECT_MENU"
    });

    collector.on("collect", async (collected) => {
      const value = collected.values[0]
      if (value === "0") {
        collected.update({ embeds: [embed], components: [row, row2] })
      }
      if (value === "1") {
        collected.update({ embeds: [embed1], components: [row, row2] })
      }
      if (value === "3") {
        collected.update({ embeds: [embed3], components: [row, row2] })
      }
      if (value === "4") {
        collected.update({ embeds: [embed4], components: [row, row2] })
      }
      if (value === "5") {
        collected.update({ embeds: [embed5], components: [row, row2] })
      }
      if (value === "6") {
        collected.update({ embeds: [embed6], components: [row, row2] })
      }
      if (value === "8") {
        collected.update({ embeds: [embed8], components: [row, row2] })
      }
      if (value === "9") {
        collected.update({ embeds: [embed9], components: [row, row2] })
      }
      if (value === "7") {
        collected.update({ embeds: [embed7], components: [row, row2] })
      }
      if (value === "10") {
        collected.update({ embeds: [embed10], components: [row, row2] })
      }
      if (value === "11") {
        collected.update({ embeds: [embed11], components: [row, row2] })
      }
    })
  }
}