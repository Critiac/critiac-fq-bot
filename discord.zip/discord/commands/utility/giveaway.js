
const { MessageEmbed } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'giveaway',
    description: 'Giveaway commands',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
            return message.reply('You need MANAGE_MESSAGES permission to manage giveaways!');
        }

        const subCommand = args[0];
        if (!subCommand) {
            return message.reply('Please use: `giveaway start`, `giveaway end`, `giveaway list`, or `giveaway reroll`');
        }

        switch (subCommand.toLowerCase()) {
            case 'start': {
                const duration = args[1];
                const winners = parseInt(args[2]);
                const prize = args.slice(3).join(' ');

                if (!duration || !winners || !prize) {
                    return message.reply('Please use the format: `giveaway start [duration] [winners] [prize]`\nExample: `giveaway start 1d 1 Discord Nitro`');
                }

                const giveawayEmbed = new MessageEmbed()
                    .setTitle('🎉 New Giveaway!')
                    .setDescription(`Prize: **${prize}**\nWinners: **${winners}**\nDuration: **${duration}**\nReact with 🎉 to enter!`)
                    .setColor('#FF5757')
                    .setFooter({ text: `Started by ${message.author.tag} | Ends` })
                    .setTimestamp(Date.now() + ms(duration));

                const msg = await message.channel.send({ embeds: [giveawayEmbed] });
                await msg.react('🎉');

                // Store giveaway data
                client.giveaways = client.giveaways || new Map();
                client.giveaways.set(msg.id, {
                    prize,
                    winners,
                    endTime: Date.now() + ms(duration),
                    channelId: message.channel.id,
                    messageId: msg.id,
                    hostId: message.author.id
                });

                // Set timer to end giveaway
                setTimeout(async () => {
                    const giveaway = client.giveaways.get(msg.id);
                    if (giveaway) {
                        await endGiveaway(client, msg.id);
                    }
                }, ms(duration));
                break;
            }

            case 'end': {
                const messageId = args[1];
                if (!messageId) {
                    return message.reply('Please provide the giveaway message ID to end.');
                }
                
                const success = await endGiveaway(client, messageId);
                if (!success) {
                    message.reply('Could not find that giveaway or it has already ended.');
                }
                break;
            }

            case 'list': {
                const activeGiveaways = Array.from(client.giveaways || [])
                    .filter(([, giveaway]) => giveaway.endTime > Date.now())
                    .map(([id, giveaway]) => `ID: ${id} - Prize: ${giveaway.prize} - Ends: <t:${Math.floor(giveaway.endTime/1000)}:R>`);

                const listEmbed = new MessageEmbed()
                    .setTitle('Active Giveaways')
                    .setDescription(activeGiveaways.length ? activeGiveaways.join('\n') : 'No active giveaways')
                    .setColor('#FF5757');

                message.channel.send({ embeds: [listEmbed] });
                break;
            }

            case 'reroll': {
                const messageId = args[1];
                if (!messageId) {
                    return message.reply('Please provide the giveaway message ID to reroll.');
                }

                const giveaway = client.giveaways.get(messageId);
                if (!giveaway) {
                    return message.reply('Could not find that giveaway.');
                }

                const channel = await client.channels.fetch(giveaway.channelId);
                const giveawayMessage = await channel.messages.fetch(messageId);
                await rerollGiveaway(client, giveawayMessage, giveaway);
                break;
            }
        }
    }
};

async function endGiveaway(client, messageId) {
    const giveaway = client.giveaways.get(messageId);
    if (!giveaway) return false;

    const channel = await client.channels.fetch(giveaway.channelId);
    const message = await channel.messages.fetch(messageId);
    const reaction = message.reactions.cache.get('🎉');
    const users = await reaction.users.fetch();
    const validUsers = users.filter(user => !user.bot);

    if (validUsers.size === 0) {
        channel.send('No valid entries for the giveaway!');
        client.giveaways.delete(messageId);
        return true;
    }

    const winners = [];
    for (let i = 0; i < giveaway.winners; i++) {
        if (validUsers.size === 0) break;
        const winner = validUsers.random();
        winners.push(winner);
        validUsers.delete(winner.id);
    }

    const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');
    channel.send(`Congratulations ${winnerMentions}! You won: **${giveaway.prize}**`);

    const endedEmbed = new MessageEmbed()
        .setTitle('🎉 Giveaway Ended!')
        .setDescription(`Prize: **${giveaway.prize}**\nWinners: ${winnerMentions}`)
        .setColor('#FF5757')
        .setFooter({ text: `Hosted by ${client.users.cache.get(giveaway.hostId).tag}` });

    message.edit({ embeds: [endedEmbed] });
    client.giveaways.delete(messageId);
    return true;
}

async function rerollGiveaway(client, message, giveaway) {
    const reaction = message.reactions.cache.get('🎉');
    const users = await reaction.users.fetch();
    const validUsers = users.filter(user => !user.bot);

    if (validUsers.size === 0) {
        return message.channel.send('No valid entries for reroll!');
    }

    const rerollWinner = validUsers.random();
    message.channel.send(`The new winner is ${rerollWinner}! Congratulations! You won: **${giveaway.prize}**`);
}
