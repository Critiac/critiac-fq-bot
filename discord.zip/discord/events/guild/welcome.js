const client = require('../../index');
const { MessageEmbed, MessageAttachment } = require("discord.js");
const wlcSchema = require("../../schemas/welcome");
const pop = require("popcat-wrapper");
const ultrax = require("ultrax") 
client.on('guildMemberAdd', async(member) => {

  

//ignore the upper part ^^

  
  
//WELCOMING SYSTEM

const wData = await wlcSchema.findOne({Guild: member.guild.id});

if(!wData) return;
  
  
   let  bg = 'https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&'
// defining the member's avatar with "PNG" as format.
let  avatar = member.user.displayAvatarURL({ format:  "png" })
// defining text_1 (title)
let  text1 = "Welcome"
// defining text_2 (subtitle)
let  text2 = member.user.tag
// defining text_3 (footer)
let  text3 = `Now we have ${member.guild.memberCount} member`
// defining the color, here its white
let  color = '#ff5a00'
// defining the options and setting them (Those are optional)

// creating the image
const image = await  ultrax.welcomeImage(bg, avatar, text1, text2, text3, color)



client.channels.cache.get(wData.Channel).send({
 files: [image]
})
  
})