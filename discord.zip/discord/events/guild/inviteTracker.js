const client = require('../../index');

//Removed InviteSchema since it's no longer used.
//const InviteSchema = require('../../schemas/invites');

// Removed invites Map
//const invites = new Map();

// Removed ready event listener
//client.on('ready', async () => {
//  client.guilds.cache.forEach(async guild => {
//    const firstInvites = await guild.invites.fetch();
//    invites.set(guild.id, new Map(firstInvites.map(invite => [invite.code, invite.uses])));
//  });
//});

// Removed guildMemberAdd event listener
//client.on('guildMemberAdd', async member => {
//  const cachedInvites = invites.get(member.guild.id);
//  const newInvites = await member.guild.invites.fetch();
//  
//  try {
//    const usedInvite = newInvites.find(invite => cachedInvites.get(invite.code) < invite.uses);
//    if (!usedInvite) return;
//
//    let inviterData = await InviteSchema.findOne({ 
//      guildId: member.guild.id,
//      inviterId: usedInvite.inviter.id 
//    });
//
//    if (!inviterData) {
//      inviterData = new InviteSchema({
//        guildId: member.guild.id,
//        inviterId: usedInvite.inviter.id,
//        inviteCode: usedInvite.code,
//        invitedUsers: [],
//        totalInvites: 0
//      });
//    }
//
//    inviterData.invitedUsers.push({
//      userId: member.id,
//      joinedAt: new Date()
//    });
//    inviterData.totalInvites += 1;
//    await inviterData.save();
//
//    const welcomeChannel = member.guild.systemChannel;
//    if (welcomeChannel) {
//      welcomeChannel.send(`Welcome ${member}! Invited by ${usedInvite.inviter} (Total invites: ${inviterData.totalInvites})`);
//    }
//
//    // Update cache
//    invites.set(member.guild.id, new Map(newInvites.map(invite => [invite.code, invite.uses])));
//  } catch (err) {
//    console.error('Error tracking invite:', err);
//  }
//});

// Removed guildCreate event listener
//client.on('guildCreate', async guild => {
//  try {
//    const firstInvites = await guild.invites.fetch();
//    invites.set(guild.id, new Map(firstInvites.map(invite => [invite.code, invite.uses])));
//  } catch (err) {
//    console.error('Error caching invites:', err);
//  }
//});