const config = require("../../botconfig/main")

const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js")
const client = require("../../index")
client.on('guildCreate', guild => {
    const channel = guild.channels.cache.find(channel => channel.type === 'GUILD_TEXT' && channel.permissionsFor(guild.me).has('SEND_MESSAGES'))
    let embed = new MessageEmbed()
        .setColor('#ff5a00')
        .setTitle('<:<:modteste:1342124747625861202> **__CONNECTED TO NEW SERVER__**')
        .setURL('https://discord.gg/2QDwvbn23X')
        .setDescription(`> <a:orange_dot:1342114334511333426>  THANKS YOU FOR INVITING ME. MY PREFIX IS &`)

        .addFields(
            { name: '<a:orange_dot:1342114334511333426> **__CREATORS__**', value: '> <a:orange_dot:1342114334511333426> Critiac' }
        )

        .setImage('https://cdn.discordapp.com/attachments/1342099778586148867/1342138613818855687/standard_13.gif?ex=67b88b7d&is=67b739fd&hm=2a9f0ccf5a313fb876e84f4e5610c1d1ebeb8f7ce40a73b8bc27ee854bc625b7&')
        .setTimestamp()
        .setFooter('SUPPORT', 'https://discord.gg/nXu9rqv6Tg');
    channel.send({ embeds: [embed] });
}) 
