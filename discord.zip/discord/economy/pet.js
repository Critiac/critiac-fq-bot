module.exports = [
  {
    name: 'Kraken',
    emoji: "<:exe_catgirl:1304705276494090240>",
    price: "30000",
    id: 'kraken'
  },
  {
    name: 'chicken',
    emoji: "<:exe_chicken:1304705278834638950>",
    price: "40000",
    id: 'chicken'
  },
  {
    name: 'catgirl',
    emoji: "<:exe_catgirl:1304705276494090240>",
    price: "60000",
    id: 'catgirl'
  }


]